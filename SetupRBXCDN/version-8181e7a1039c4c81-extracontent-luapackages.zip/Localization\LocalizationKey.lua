local CorePackages = game:GetService("CorePackages")
local Symbol = require(CorePackages.Symbol)

return Symbol.named("Localization")