local InGameMenuDependencies = script.Parent

return {
	Roact = require(InGameMenuDependencies.Roact),
	Rodux = require(InGameMenuDependencies.Rodux),
	RoactRodux = require(InGameMenuDependencies.RoactRodux),
	UIBlox = require(InGameMenuDependencies.UIBlox),
	Otter = require(InGameMenuDependencies.Otter),
	Cryo = require(InGameMenuDependencies.Cryo),
	t = require(InGameMenuDependencies.t),
	PolicyProvider = require(InGameMenuDependencies.PolicyProvider),
	Promise = require(InGameMenuDependencies.Promise),
}
