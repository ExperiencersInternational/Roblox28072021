-----------------------------------------------------------------------------
---                                                                       ---
---                   Under Migration to CorePackages                     ---
---                                                                       ---
---                 Please put your changes in Analytics.                 ---
-----------------------------------------------------------------------------
local CorePackages = game:GetService("CorePackages")
return require(CorePackages.Analytics.AnalyticsReporters.Diag)
