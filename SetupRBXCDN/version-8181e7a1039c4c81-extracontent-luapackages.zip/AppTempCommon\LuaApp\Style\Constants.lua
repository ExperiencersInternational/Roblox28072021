local Constants = {}

Constants.ThemeName = {
	Dark = "dark",
	Light = "light",
}

Constants.FontName = {
	Gotham = "gotham",
}

return Constants