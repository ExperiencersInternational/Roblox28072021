return function()
	it("should load", function()
		require(script.Parent)
	end)
end