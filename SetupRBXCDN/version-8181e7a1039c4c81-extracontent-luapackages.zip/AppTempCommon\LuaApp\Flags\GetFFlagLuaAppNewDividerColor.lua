game:DefineFastFlag("LuaAppNewDividerColor", false)

return function()
	return game:GetFastFlag("LuaAppNewDividerColor")
end