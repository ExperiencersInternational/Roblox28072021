local CorePackages = game:GetService("CorePackages")

local initify = require(CorePackages.initify)

initify(CorePackages.SymbolImpl)

return require(CorePackages.SymbolImpl)