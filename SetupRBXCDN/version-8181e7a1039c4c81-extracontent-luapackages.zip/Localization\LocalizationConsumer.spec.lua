return function()
	itSKIP("SOC-6353 - These unit tests need to be moved from LuaApp", function()
	end)
end