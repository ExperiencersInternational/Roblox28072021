local symbols = require(script.symbols)

return {
	MagicMock = require(script.MagicMock),
	AnyCallMatches = require(script.AnyCallMatches),
	getCalls = require(script.getCalls),
	Spy = require(script.Spy),
}