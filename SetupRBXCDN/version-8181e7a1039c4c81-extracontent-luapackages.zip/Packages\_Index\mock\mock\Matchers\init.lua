return {
	toBeAMagicMock = require(script.toBeAMagicMock),
	toBeASpy = require(script.toBeASpy),
	toHaveBeenCalled = require(script.toHaveBeenCalled),
	toHaveBeenCalledWith = require(script.toHaveBeenCalledWith),
}
