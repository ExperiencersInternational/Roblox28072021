return {
	above = require(script.Parent.above),
	alignedHorizontally = require(script.Parent.alignedHorizontally),
	alignedVertically = require(script.Parent.alignedVertically),
	below = require(script.Parent.below),
	inside = require(script.Parent.inside),
	insideAbove = require(script.Parent.insideAbove),
	insideBelow = require(script.Parent.insideBelow),
	insideLeftOf = require(script.Parent.insideLeftOf),
	insideRightOf = require(script.Parent.insideRightOf),
	intersect = require(script.Parent.intersect),
	leftOf = require(script.Parent.leftOf),
	rightOf = require(script.Parent.rightOf),
}
