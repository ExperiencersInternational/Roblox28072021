local LuaChatDeps = script.Parent

return {
	InfiniteScroll = require(LuaChatDeps.InfiniteScroller),
	RoduxNetworking = require(LuaChatDeps.RoduxNetworking),
	UIBlox = require(LuaChatDeps.UIBlox),
	AssetCard = require(LuaChatDeps.AssetCard),
}
