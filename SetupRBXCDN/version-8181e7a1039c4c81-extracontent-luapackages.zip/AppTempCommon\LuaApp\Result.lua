-----------------------------------------------------------------------------
---                                                                       ---
---                   Under Migration to CorePackages                     ---
---                                                                       ---
-----------------------------------------------------------------------------
local CorePackages = game:GetService("CorePackages")

return require(CorePackages.Result)
