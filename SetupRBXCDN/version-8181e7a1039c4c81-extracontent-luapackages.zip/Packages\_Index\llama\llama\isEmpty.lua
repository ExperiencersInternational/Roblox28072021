
local function isEmpty(object)
	return next(object) == nil
end

return isEmpty